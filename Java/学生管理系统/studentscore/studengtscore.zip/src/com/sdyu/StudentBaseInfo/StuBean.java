package com.sdyu.StudentBaseInfo;

public class StuBean {
	String no;
	String name;
	String class_no;
	double chinese;
	double math;
	double english;
	
	public StuBean(){
		
	}
	
	public StuBean(String no, String name,String class_no, double chinese, double math,
			double english) {
		
		this.no = no;
		this.name = name;
		this.class_no = class_no;
		this.chinese = chinese;
		this.math = math;
		this.english = english;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClass_no() {
		return class_no;
	}
	public void setClass_no(String class_no) {
		this.class_no = class_no;
	}
	public double getChinese() {
		return chinese;
	}
	public void setChinese(double chinese) {
		this.chinese = chinese;
	}
	public double getMath() {
		return math;
	}
	public void setMath(double math) {
		this.math = math;
	}
	public double getEnglish() {
		return english;
	}
	public void setEnglish(double english) {
		this.english = english;
	}
	
	

}
