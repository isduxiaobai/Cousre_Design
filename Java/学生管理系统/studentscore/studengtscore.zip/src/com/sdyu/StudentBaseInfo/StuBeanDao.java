package com.sdyu.StudentBaseInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.sdyu.util.ConnectionUtil;

public class StuBeanDao {

	Connection con = null;
	Statement st = null;
	ResultSet rs = null;
	String sql = null;
	PreparedStatement ps = null;

	/*
	 * ����ѧ����Ϣ
	 */
	public int insertStu(StuBean stu) {
		String number = stu.getNo();
		String name = stu.getName();
		String classno = stu.getClass_no();
		double chinese = stu.getChinese();
		double english = stu.getEnglish();
		double maths = stu.getMath();
		int result = 0;
		sql = "insert into Student(no,name,class_no,chinese,english,math) values('"
				+ number
				+ "','"
				+ name
				+ "','"
				+ classno
				+ "',"
				+ chinese
				+ "," + english + "," + maths + ");";
		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			result = st.executeUpdate(sql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}

		return result;

	}

	/*
	 * ɾ��ѧ����Ϣ
	 */
	public int deleteStu(String stuno) {

		int result = 0;

		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			String sql = "select * from Student where no='" + stuno + "'";
			rs = st.executeQuery(sql);

			while (rs.next()) {
				sql = "delete from Student where no=?";
				ps = con.prepareStatement(sql);
				ps.setString(1, stuno);
				result = ps.executeUpdate();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}

		return result;
	}

	/*
	 * �޸�ѧ����Ϣ
	 */
	public int updateStu(StuBean stu) {
		String number = stu.getNo();
		String name = stu.getName();
		String classno = stu.getClass_no();
		double chinese = stu.getChinese();
		double english = stu.getEnglish();
		double maths = stu.getMath();
		int result = 0;
		sql = "update Student set name='"
				+ name
				+ "',"
				+ "class_no='"
				+ classno
				+ "',"
				+ "chinese="
				+ chinese
				+ "," + "english="+english + "," +"math="+ maths 
				+ "  where no='"+number+"';";
		
		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			result = st.executeUpdate(sql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}

		return result;
	}

	/*
	 * ��ѯ����ѧ����Ϣ
	 */
	
	public String[][] searchAll(){
		String[][] result=null;
		int row=0;
		int i=0;
		sql="select * from student order by no";
		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(sql);
			if(rs.last()){
				row=rs.getRow();
				
			}
			if(row==0){
				result=null;
			}else{
				result=new String[row][6];
				rs.first();
				rs.previous();
				while(rs.next()){
					result[i][0]=rs.getString("no");
					result[i][1]=rs.getString("name");
					result[i][2]=rs.getString("class_no");
					result[i][3]=Double.toString(rs.getDouble("chinese"));
					result[i][4]=Double.toString(rs.getDouble("math"));
					result[i][5]=Double.toString(rs.getDouble("english"));
					i++;

				}
				
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}
		
		return result;
	}
	
	

	/*
	 * ����ѧ�Ų�ѯѧ����Ϣ
	 */
	
	public String[] searchById(String stuno){
		String[] result=null;		
		
		sql="select * from student where no='"+stuno+"'";
		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(sql);
			result=new String[6];
			if(rs.next()){
					result[0]=rs.getString("no");
					result[1]=rs.getString("name");
					result[2]=rs.getString("class_no");
					result[3]=Double.toString(rs.getDouble("chinese"));
					result[4]=Double.toString(rs.getDouble("math"));
					result[5]=Double.toString(rs.getDouble("english"));
			}
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}
		
		return result;
	}
	
	/*
	 * ����������ѯѧ����Ϣ
	 */
	
	public String[] searchByName(String stuname){
		String[] result=null;
		int row=0;
		
		sql="select * from student where name='"+stuname+"'";
		try {
			con = ConnectionUtil.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(sql);
			result=new String[6];
			if(rs.next()){
					result[0]=rs.getString("no");
					result[1]=rs.getString("name");
					result[2]=rs.getString("class_no");
					result[3]=Double.toString(rs.getDouble("chinese"));
					result[4]=Double.toString(rs.getDouble("math"));
					result[5]=Double.toString(rs.getDouble("english"));
			}
			} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			ConnectionUtil.closeConn();
		}
		
		return result;
	}
	
	/*
	 * ���ݰ༶��ѯѧ����Ϣ
	 */
	
	public String[][] searchByClass(String classno){
		
			String[][] result=null;
			int row=0;
			int i=0;
			sql="select * from student where class_no='"+classno+"'";
			try {
				con = ConnectionUtil.getConnection();
				st = con.createStatement();
				rs = st.executeQuery(sql);
				if(rs.last()){
					row=rs.getRow();
					
				}
				if(row==0){
					result=null;
				}else{
					result=new String[row][6];
					rs.first();
					rs.previous();
					while(rs.next()){
						result[i][0]=rs.getString("no");
						result[i][1]=rs.getString("name");
						result[i][2]=rs.getString("class_no");
						result[i][3]=Double.toString(rs.getDouble("chinese"));
						result[i][4]=Double.toString(rs.getDouble("math"));
						result[i][5]=Double.toString(rs.getDouble("english"));
						i++;

					}
					
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				ConnectionUtil.closeConn();
			}
			
			return result;
		}
		
	

}
