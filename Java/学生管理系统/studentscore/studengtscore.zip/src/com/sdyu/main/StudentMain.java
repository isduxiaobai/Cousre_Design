package com.sdyu.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import com.sdyu.StudentBaseInfo.StuBaseInfoFrame;



public class StudentMain extends JFrame implements ActionListener {
	JMenuBar menubar;
    JMenu menu,menu2,subMenu2;
    JMenuItem  subMenu,itemLiterature,itemCooking;
    
    public StudentMain(){} 
    public StudentMain(String s,int x,int y,int w,int h) {
       init(s);
       setLocation(x,y);
       setSize(w,h);
       setVisible(true);
       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
    }
    void init(String s){
       setTitle(s);             //���ô��ڵı���   
       menubar=new JMenuBar(); 
       menu=new JMenu("ѧ����Ϣ����"); 
       menu2=new JMenu("ѧ��������Ϣ����"); 
       
       subMenu=new JMenuItem("ѧ��������Ϣ����");  
       subMenu2=new JMenu("ѧ���������"); 
       itemLiterature=new JMenuItem("��ѧ����",new ImageIcon("a.gif"));
       itemCooking=new JMenuItem("��⿻���",new ImageIcon("b.gif"));
       
       menu.add(subMenu);
       menu.addSeparator();   //�ڲ˵�֮�����ӷָ���
       menu.add(subMenu2);
       subMenu2.add(itemLiterature); 
       subMenu2.add(itemCooking); 
       
       menubar.add(menu); 
       menubar.add(menu2); 
       setJMenuBar(menubar);
       
       //���Ӳ˵��¼�����
       subMenu.addActionListener(this);
       itemLiterature.addActionListener(this);
    } 
    
    //�˵��¼�����
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj=e.getSource();		
		if(obj==subMenu){
			
			StuBaseInfoFrame sf=new StuBaseInfoFrame();
		}
		
	}

}
