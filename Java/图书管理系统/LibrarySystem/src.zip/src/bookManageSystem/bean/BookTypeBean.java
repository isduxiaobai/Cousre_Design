package bookManageSystem.bean;

/*
@Author:杜小白
@Time: 2021/12/5 20:42
@File: BookTypeBean.java
@Software: IntelliJ IDEA
@Email: 1289558057@qq.com 
@WeChat official account：杜小白IU
*/
public class BookTypeBean {
    private int bookTypeId;
    private String bookTypeName;
    private String bookTypeDescription;

    public BookTypeBean() {
    }

    public BookTypeBean(int bookTypeId, String bookTypeName, String bookTypeDescription) {
        this.bookTypeId = bookTypeId;
        this.bookTypeName = bookTypeName;
        this.bookTypeDescription = bookTypeDescription;
    }

    public int getBookTypeId() {
        return bookTypeId;
    }

    public void setBookTypeId(int bookTypeId){
        this.bookTypeId = bookTypeId;
    }

    public String getBookTypeName(){
        return bookTypeName;
    }

    public void setBookTypeName(String bookTypeName){
        this.bookTypeName = bookTypeName;
    }

    public String getBookTypeDescription() {
        return bookTypeDescription;
    }

    public void setBookTypeDescription(String bookTypeDescription){
        this.bookTypeDescription = bookTypeDescription;
    }

}